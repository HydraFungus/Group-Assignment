package com.example.groupassignment;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Show {
    private String title;
    private Date showtime;
    private String theatre;
    private String duration;
    private String rating;
    private String url;
    private String imagelink;

    //"Title"));
    //showlist.add(new SimpleDateFormat("yyyy-MM-d'T'HH:mm").parse(showElement.getAttribute("dttmShowStart")).toString());showlist.add(showElement.getAttribute("Theatre"));
    //"Rating"));
    //"LengthInMinutes"));
    //"ShowURL"));
    //"Images", "EventMediumImagePortrait"));

    @Override
    public String toString() {
        return "Show{" +
                "Title='" + title + '\'' +
                "Start time ='" + showtime+'\''+
                "Theatre ='" + theatre+'\''+
                "Show lenght= '"+duration + '\'' +
                ", Rating='" + rating + '\'' +
        ", Show url='" + url + '\'' +
                "Image available at ='"+ imagelink+'\''+
        '}';
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String t) {
        t=title;
    }

    public  Date getShowtime() {return showtime;}
    public void setShowtime(String s){
        try {
            Date d=new SimpleDateFormat("yyyy-MM-d'T'HH:mm").parse(s);
            d= showtime;
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }


    public String getTheatre() {return theatre;}
    public void setTheatre(String t){
        t=theatre;
    }

    public String getLengthInMinutes() {
        return duration;
    }

    public void setLengthInMinutes(String l) {
        l= duration;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String r) {

        r=rating;
    }

    public String getURL() {
        return url;
    }

    public void setURL(String u) {
        u=url;
    }

    public String getImage() {return imagelink;}

    public void setImagelink(String i) {
        i=imagelink;
    }


}

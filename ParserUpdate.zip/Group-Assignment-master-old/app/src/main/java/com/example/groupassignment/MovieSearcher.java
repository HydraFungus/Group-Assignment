package com.example.groupassignment;

import static android.R.layout.*;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.DocumentsContract;
import android.util.Log;
import android.util.LogPrinter;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xmlpull.v1.XmlPullParserException;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyStore;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;


public class MovieSearcher extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_searcher);
        //StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        //StrictMode.setThreadPolicy(policy);
    }

        public void readXML (View v){

            Date date;
            Intent intent;
            String theatre;
            String d;


            ArrayList<Show> showlist = new ArrayList();
            intent = getIntent();
            theatre = intent.getStringExtra("key1");
            d = intent.getStringExtra("key2");

            date = null;


            {
                try {
                    date = new SimpleDateFormat("dd/MM/yyyy").parse(d);
                } catch (ParseException e) {
                    e.printStackTrace();
                }


                /* Get Document Builder
                 *Get Document
                 * Normalize the xml structure
                 * *Get all of the wanted elements by tag name
                 */


                {

                    try {
                        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                        DocumentBuilder builder;


                        builder = factory.newDocumentBuilder();


                        String url = "\"https://www.finnkino.fi/xml/Schedule/\"";
                        //get document

                        Document doc = builder.parse(url);

                        Toast.makeText(this, /*(CharSequence) showlist.get(0)*/"moi",
                                Toast.LENGTH_LONG).show();

                        //Normalize the xml structure

                        doc.getDocumentElement().normalize();
                        Toast.makeText(this, /*(CharSequence) showlist.get(0)*/"moi",
                                Toast.LENGTH_LONG).show();

                        //Get wanted elements by tag name

                        NodeList showList = doc.getElementsByTagName("Shows");
                        Toast.makeText(this, /*(CharSequence) showlist.get(0)*/"moi",
                                Toast.LENGTH_LONG).show();


                        for (int i = 0; i < showList.getLength(); i++) {
                            Node Show = showList.item(i);
                            Toast.makeText(this, /*(CharSequence) showlist.get(0)*/"moi",
                                    Toast.LENGTH_LONG).show();

                            if (Show.getNodeType() == Node.ELEMENT_NODE) {
                                Element showElement = (Element) Show;

                                NodeList showDetails = Show.getChildNodes();
                                for (int j = 0; j < showDetails.getLength(); j++) {
                                    Show show = new Show();
                                    Node detail = showDetails.item(j);
                                    if (detail.getNodeType() == Node.ELEMENT_NODE) {
                                        Element detailElement = (Element) detail;

                                        if (showElement.getAttribute("Theatre") == theatre) {
                                            Date start = new SimpleDateFormat("yyyy-MM-d").parse(showElement.getAttribute("dttmShowStart"));
                                            if (start == date) {
                                                showlist.add(show);
                                                showlist.set(j, show).setTitle(showElement.getAttribute("Title"));
                                                showlist.set(j, show).setShowtime(new SimpleDateFormat("yyyy-MM-d'T'HH:mm").parse(showElement.getAttribute("dttmShowStart")).toString());
                                                showlist.set(j, show).setRating(showElement.getAttribute("Rating"));
                                                showlist.set(j, show).setTheatre(showElement.getAttribute("Theatre"));
                                                showlist.set(j, show).setLengthInMinutes(showElement.getAttribute("LengthInMinutes"));
                                                showlist.set(j, show).setURL(showElement.getAttribute("ShowURL"));
                                                showlist.set(j, show).setImagelink(showElement.getElementsByTagNameNS("Images", "EventMediumImagePortrait").toString());

                                                Toast.makeText(this, /*(CharSequence) showlist.get(0)*/"moi",
                                                        Toast.LENGTH_LONG).show();
                                            }

                                        }
                                    }
                                }


                            }
                        }
                        //Spinner sp3 = (Spinner) findViewById(R.id.spinner3);
                        //ArrayAdapter<String> parseAdapter = new ArrayAdapter<String>(MovieSearcher.this, android.R.layout.simple_list_item_1, showlist);
                        //parseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        //sp3.setAdapter(parseAdapter);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }


            }

        }
    }


